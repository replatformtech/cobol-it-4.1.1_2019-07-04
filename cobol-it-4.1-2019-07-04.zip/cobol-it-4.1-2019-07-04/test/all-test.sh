COBOL_FLAGS="$* ${COBOL_FLAGS}"
export COBOL_FLAGS
sh run
sh syntax
sh data-rep
