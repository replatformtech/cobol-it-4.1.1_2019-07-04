static char octardate[] = "Thu Jul  4 01:44:44 CEST 2019";
