/*CIT_BEGIN_ENTERPRISE*/
/*
 * Copyright (C) 2008-2009 CobolIT
 *
 * This code is proprety of COBOL-IT . 
 * Usage of this code or any part of it require a explicit writen authoristion of COBOL-IT
 */

#ifndef MF_DEBUG_1_H
#define MF_DEBUG_1_H

#include "enterprise/debug.h"

#endif  /*MF_EXTFH_1_H*/
